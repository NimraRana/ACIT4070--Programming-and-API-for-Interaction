﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace NorwegianRails
{
    public partial class ChangeCancel : Form
    {
        public ChangeCancel()
        {
            InitializeComponent();
        }
        //Cancel ticket button code
        private void button2_Click(object sender, EventArgs e)
        {
            if(textBox1.Text=="")
            {
                MessageBox.Show("Please enter Ticket Number!", "Ticket Number Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            { 
            MySqlConnection sqlconn = new MySqlConnection();
            MySqlCommand sqlcmd = new MySqlCommand();
            MySqlDataReader sqlRd;


            sqlconn.ConnectionString = "datasource=localhost; port=3306; username=root; database=nrails";
            sqlconn.Open();
            sqlcmd.CommandText = "DELETE FROM `tickets` WHERE id='" + textBox1.Text + "'";
            sqlcmd.Connection = sqlconn;

            sqlRd = sqlcmd.ExecuteReader();
            sqlconn.Close();
            
             MessageBox.Show("Your Ticket is cancelled Now!\nPayment retuned to your linked account!", "Ticket Cancelled", MessageBoxButtons.OK, MessageBoxIcon.Information);
                
            
            }
        }
        //Change ticket button code
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("Please enter Ticket Number!", "Ticket Number Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                String cid = textBox1.Text;
                
                ReserveSeat rs = new ReserveSeat();

                if (button1.Text == "Show Ticket")
                {
                    rs.showOnly("show");
                    rs.Text = "Show Ticket";
                    rs.saveChange(cid, "show");
                }
                else
                {
                    rs.Text = "Change Ticket Details";
                    rs.saveChange(cid, "change");
                }
                
                rs.Show();
                this.Hide();
                
            }
        }

        //Main Menu button code
        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
            SelectionWin sw = new SelectionWin();
            sw.Show();
        }
        //Function to change label and button for show ticket option
        public void showTicket()
        {
            label3.Visible = false;
            label2.Visible = true;
            button1.Text = "Show Ticket";
            button2.Visible = false;
        }
    }
}
