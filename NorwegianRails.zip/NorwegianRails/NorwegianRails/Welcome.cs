﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NorwegianRails
{
    public partial class Welcome : Form
    {
        public Welcome()
        {
            InitializeComponent();
        }
        //Exit button code
        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        //Log In button code
        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 li = new Form1();
            li.Show();
        }
        //Start as new visitor button code
        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            SelectionWin sw = new SelectionWin();
            sw.Text = "Please make a Selection";
            sw.exitPage("welcome");
            sw.Show();
        }
    }
}
