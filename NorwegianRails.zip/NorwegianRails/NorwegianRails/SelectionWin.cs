﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NorwegianRails
{
    public partial class SelectionWin : Form
    {
        public SelectionWin()
        {
            InitializeComponent();
        }
        //Exit page path decision
        String closeButton = "";
        public void exitPage(String text)
        {
            closeButton = text;
            if(text=="login")
                button4.Text = "Log Out";
        }
        //Cancel button code
        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
            if (closeButton == "login")
            {
                Form1 op = new Form1();
                op.Show();
            }
            else
            {
                Welcome wc = new Welcome();
                wc.Show();               
            }
        }
        //Purchase a ticket button code
        private void button1_Click(object sender, EventArgs e)
        {
            PurchaseTicket pt = new PurchaseTicket();
            pt.Text = "Purchase a Ticket";
            pt.Show();
            this.Hide();
        }
        //Reserve Seats button code
        private void button2_Click(object sender, EventArgs e)
        {
            SelectSeat rs = new SelectSeat();
            rs.Text = "Reserve Seat";
            rs.taken();
            rs.Show();
            this.Hide();
        }
        
        //Change/Cancel ticket button code
        private void button3_Click(object sender, EventArgs e)
        {
            ChangeCancel cc = new ChangeCancel();
            cc.Show();
            this.Hide();
        }


        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
        //Show Ticket button code
        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            ChangeCancel st = new ChangeCancel();
            st.showTicket();
            st.Show();
        }
    }
}
