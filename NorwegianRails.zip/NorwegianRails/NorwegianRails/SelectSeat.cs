﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace NorwegianRails
{
    public partial class SelectSeat : Form
    {
        public SelectSeat()
        {
            InitializeComponent();
        }

        private void SelectSeat_Load(object sender, EventArgs e)
        {
            this.taken();
        }
        //Function for listing taken seats
        public void taken()
        {
            MySqlConnection sqlconn = new MySqlConnection();
            MySqlCommand sqlcmd = new MySqlCommand();
            MySqlDataAdapter sqlad = new MySqlDataAdapter();
            DataTable sqldt = new DataTable();
            //MySqlDataReader sqlRd;
            MySqlCommandBuilder sqlcb = new MySqlCommandBuilder();
            sqlconn.ConnectionString = "datasource=localhost; port=3306; username=root; database=nrails";
            sqlconn.Open();
            sqlcmd.Connection = sqlconn;
            sqlcmd.CommandText = "SELECT seat FROM rseats WHERE seat > 0";
            sqlad.SelectCommand = sqlcmd;
            sqlad.Fill(sqldt);
            listBox1.DataSource = sqldt;
            listBox1.ValueMember = "seat";
        }
        //Get ticket number button code
        private void button1_Click(object sender, EventArgs e)
        {
            String tick = "";
            MySqlConnection sqlconn = new MySqlConnection();
            MySqlCommand sqlcmd = new MySqlCommand();
            MySqlDataReader sqlRd;

            sqlconn.ConnectionString = "datasource=localhost; port=3306; username=root; database=nrails";
            sqlconn.Open();
            
            //Getting ticket number from database table id
            sqlcmd.CommandText = "SELECT id FROM `tickets` WHERE id=( SELECT MAX(id) FROM `tickets` )";
            sqlcmd.Connection = sqlconn;
            sqlRd = sqlcmd.ExecuteReader();
            if (sqlRd.Read())
            {
                tick = sqlRd[0].ToString();
            }
            sqlconn.Close();

            MessageBox.Show("Your ticket number is " + tick, "Ticket Number", MessageBoxButtons.OK, MessageBoxIcon.Information);
                button1.Enabled = false;
            
        }
        //Cancel button code
        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            TimeSch tt = new TimeSch();
            tt.Show();
        }
        //Pay Now button code
        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Connected to the bank account successfully!", "Payment Status", MessageBoxButtons.OK, MessageBoxIcon.Information);
            button4.Enabled = false;
        }
        //Add seat button code
        int passCount = 0;
        private void button3_Click(object sender, EventArgs e)
        {
            //Validating the filling of input fields


            listBox1.ClearSelected();

            int index = listBox1.FindString(textBox2.Text);

            if (index > 0)
            {
                listBox1.SelectedIndex = index;
                MessageBox.Show("This seat is already taken!\nPlease enter a different seat!", "Invalid Seat", MessageBoxButtons.OK, MessageBoxIcon.Warning);

            }
            else if (textBox1.Text == "" || textBox2.Text == "")
            {
                MessageBox.Show("All the inputs are mandatory!", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if(Convert.ToDecimal(textBox2.Text) <=  0 || Convert.ToDecimal(textBox2.Text) > 100 )
            {
                MessageBox.Show("Please enter a valid seat number ranging 1 to 100!", "Invalid Seat", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                passCount = passCount + 1;
                MySqlConnection sqlconn = new MySqlConnection();
                MySqlCommand sqlcmd = new MySqlCommand();
                MySqlDataReader sqlRd;

                
                sqlconn.ConnectionString = "datasource=localhost; port=3306; username=root; database=nrails";
                sqlconn.Open();

                
                
                if (passCount == 1)
                {
                    sqlcmd.CommandText = "UPDATE `tickets` SET  `name1` = '" + textBox1.Text + "', `seat1` ='" + textBox2.Text +
                        "' where `id`=( SELECT MAX(id) FROM `tickets` )";
                    sqlcmd.Connection = sqlconn;
                    sqlRd = sqlcmd.ExecuteReader();
                    sqlRd.Close();

                    sqlcmd.CommandText = "INSERT INTO `rseats`(`seat`) VALUES('" + textBox2.Text + "')";
                    sqlcmd.Connection = sqlconn;
                    sqlRd = sqlcmd.ExecuteReader();

                    sqlconn.Close();
                    this.taken();
                }
                else if (passCount == 2)
                {
                    sqlcmd.CommandText = "UPDATE `tickets` SET  `name2` = '" + textBox1.Text + "', `seat2` ='" + textBox2.Text +
                        "' where `id`=( SELECT MAX(id) FROM `tickets` )";
                    sqlcmd.Connection = sqlconn;
                    sqlRd = sqlcmd.ExecuteReader();
                    sqlRd.Close();

                    sqlcmd.CommandText = "INSERT INTO `rseats`(`seat`) VALUES('" + textBox2.Text + "')";
                    sqlcmd.Connection = sqlconn;
                    sqlRd = sqlcmd.ExecuteReader();

                    sqlconn.Close();
                    this.taken();

                }
                else if (passCount == 3)
                {
                    sqlcmd.CommandText = "UPDATE `tickets` SET  `name3` = '" + textBox1.Text + "', `seat3` ='" + textBox2.Text +
                        "' where `id`=( SELECT MAX(id) FROM `tickets` )";
                    sqlcmd.Connection = sqlconn;
                    sqlRd = sqlcmd.ExecuteReader();
                    sqlRd.Close();

                    sqlcmd.CommandText = "INSERT INTO `rseats`(`seat`) VALUES('" + textBox2.Text + "')";
                    sqlcmd.Connection = sqlconn;
                    sqlRd = sqlcmd.ExecuteReader();

                    sqlconn.Close();
                    this.taken();

                }
                else if (passCount == 4)
                {
                    sqlcmd.CommandText = "UPDATE `tickets` SET  `name4` = '" + textBox1.Text + "', `seat4` ='" + textBox2.Text +
                        "' where `id`=( SELECT MAX(id) FROM `tickets` )";
                    sqlcmd.Connection = sqlconn;
                    sqlRd = sqlcmd.ExecuteReader();
                    sqlRd.Close();

                    sqlcmd.CommandText = "INSERT INTO `rseats`(`seat`) VALUES('" + textBox2.Text + "')";
                    sqlcmd.Connection = sqlconn;
                    sqlRd = sqlcmd.ExecuteReader();

                    sqlconn.Close();
                    this.taken();

                }
                else
                {
                    MessageBox.Show("Maximum seats added! ", "Seats Status", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                

                //MessageBox.Show("Seat Reserved for Ticket " + textBox1.Text + " Successfully!", "Reservation Status", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            SelectionWin sw = new SelectionWin();
            sw.Show();
            
        }
    }
}
