﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace NorwegianRails
{
    public partial class ReserveSeat : Form
    {
        public ReserveSeat()
        {
            InitializeComponent();
        }
        
        String rid = "";
        //Function to customize change ticket window and opening the ticket details from database table
        public void saveChange(String a, String func)
        {
            rid = a;

            MySqlConnection sqlconn = new MySqlConnection();
            MySqlCommand sqlcmd = new MySqlCommand();
            MySqlDataReader sqlRd;

            sqlconn.ConnectionString = "datasource=localhost; port=3306; username=root; database=nrails";
            sqlconn.Open();
            

            sqlcmd.CommandText = "SELECT date,trip,source,dest,passengers,name1,seat1,name2,seat2,name3,seat3,name4,seat4 FROM `tickets` WHERE id=" + a;
            sqlcmd.Connection = sqlconn;
            sqlRd = sqlcmd.ExecuteReader();

            if (sqlRd.Read())
            {
               
                dateTimePicker1.Value = Convert.ToDateTime(sqlRd[0]);
                
                if (sqlRd[1].ToString() == "One Way Trip")
                    radioButton1.Checked = true;
                else if (sqlRd[1].ToString() == "Round Trip")
                    radioButton2.Checked = true;

                comboBox1.Text = sqlRd[2].ToString();
                comboBox2.Text = sqlRd[3].ToString();
                numericUpDown1.Value = Convert.ToDecimal(sqlRd[4]);

                if (func == "show")
                {
                    if (sqlRd[5].ToString() != "")
                    {
                        textBox1.Text = sqlRd[5].ToString();
                    }
                    if (sqlRd[6].ToString() != "")
                    {
                        textBox2.Text = sqlRd[6].ToString();
                    }

                    if (sqlRd[7].ToString() != "")
                    {
                        textBox4.Visible = true;
                        textBox4.Text = sqlRd[7].ToString();
                    }
                    if (Convert.ToDecimal(sqlRd[8]) != 0)
                    {
                        textBox3.Visible = true;
                        textBox3.Text = sqlRd[8].ToString();
                    }

                    if (sqlRd[9].ToString() != "")
                    {
                        textBox6.Visible = true;
                        textBox6.Text = sqlRd[9].ToString();
                    }
                    if (Convert.ToDecimal(sqlRd[10]) != 0)
                    {
                        textBox5.Visible = true;
                        textBox5.Text = sqlRd[10].ToString();
                    }

                    if (sqlRd[11].ToString() != "")
                    {
                        textBox8.Visible = true;
                        textBox8.Text = sqlRd[11].ToString();
                    }
                    if (Convert.ToDecimal(sqlRd[12]) != 0)
                    {
                        textBox7.Visible = true;
                        textBox7.Text = sqlRd[12].ToString();
                    }
                }
                else
                {

                   
                        textBox1.Text = sqlRd[5].ToString();
                    
                    if (sqlRd[6].ToString() != "")
                    {
                        textBox2.Text = sqlRd[6].ToString();
                    }

                     textBox4.Visible = true;
                     textBox4.Text = sqlRd[7].ToString();

                    textBox3.Visible = true;
                    if (Convert.ToDecimal(sqlRd[8]) != 0)
                    {
                        
                        textBox3.Text = sqlRd[8].ToString();
                    }

                    textBox6.Visible = true;
                    textBox6.Text = sqlRd[9].ToString();

                    textBox5.Visible = true;
                    if (Convert.ToDecimal(sqlRd[10]) != 0)
                    {
                        
                        textBox5.Text = sqlRd[10].ToString();
                    }

                    textBox8.Visible = true;
                    textBox8.Text = sqlRd[11].ToString();

                    textBox7.Visible = true;
                    if (Convert.ToDecimal(sqlRd[12]) != 0)
                    {
                        
                        textBox7.Text = sqlRd[12].ToString();
                    }

                }


            }
            sqlconn.Close();
           
        }
        //Save changes button code
        private void button2_Click(object sender, EventArgs e)
        {
            String trip = "";
            if (radioButton1.Checked == true)
                trip = "One Way Trip";
            else if (radioButton2.Checked == true)
                trip = "Round Trip";

           

            //Validating place and seat
            if(comboBox1.Text==comboBox2.Text)
            {
                MessageBox.Show("Please enter different places in Froma and To!", "Indifferent Places", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (textBox2.Text != "" && (Convert.ToDecimal(textBox2.Text) <= 0 || Convert.ToDecimal(textBox2.Text) > 100))
            {
                
                  MessageBox.Show("Please enter a valid seat number ranging 1 to 100!", "Invalid Seat", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                
            }
            else if (textBox3.Text != "" && (Convert.ToDecimal(textBox3.Text) <= 0 || Convert.ToDecimal(textBox3.Text) > 100))
            {
               
                  MessageBox.Show("Please enter a valid seat number ranging 1 to 100!", "Invalid Seat", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                
            }
            else if (textBox5.Text != "" && (Convert.ToDecimal(textBox5.Text) <= 0 || Convert.ToDecimal(textBox5.Text) > 100))
            {
                
                  MessageBox.Show("Please enter a valid seat number ranging 1 to 100!", "Invalid Seat", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                
               
            }
            else if (textBox7.Text != "" && (Convert.ToDecimal(textBox7.Text) <= 0 || Convert.ToDecimal(textBox7.Text) > 100))
            {
                
                  MessageBox.Show("Please enter a valid seat number ranging 1 to 100!", "Invalid Seat", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                
            }
            //Saving changes to database
            else
            {
                MySqlConnection sqlconn = new MySqlConnection();
                MySqlCommand sqlcmd = new MySqlCommand();
                MySqlDataReader sqlRd;

                sqlconn.ConnectionString = "datasource=localhost; port=3306; username=root; database=nrails";
                sqlconn.Open();

                sqlcmd.CommandText = "UPDATE `tickets` SET `date` = '" + dateTimePicker1.Value.Date.ToString("yyyyMMdd") + "', `trip` ='" + trip + "', `source` = '" + comboBox1.Text +
                        "', `dest` = '" + comboBox2.Text + "', `passengers` = '" + numericUpDown1.Value + "', `name1` = '" + textBox1.Text + "', `seat1` = '" + textBox2.Text +
                        "', `name2` = '" + textBox4.Text + "', `seat2` = '" + textBox3.Text + "', `name3` = '" + textBox6.Text + "', `seat3` = '" + textBox5.Text +
                        "', `name4` = '" + textBox8.Text + "', `seat4` = '" + textBox7.Text +
                        "' where `id` = '" + rid + "'";
                sqlcmd.Connection = sqlconn;
                sqlRd = sqlcmd.ExecuteReader();

                sqlconn.Close();
                MessageBox.Show("Ticket " + rid + " Changed Successfully!", "Change Ticket", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        //Main Menu button code
        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
            SelectionWin sw = new SelectionWin();
            sw.Show();

        }
        //Hiding save changes for show ticket
        public void showOnly(String caller)
        {
            if (caller == "show")
            {
                button2.Visible = false;
                button1.Visible = true;
            }

        }
    }
}
