﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace NorwegianRails
{
    public partial class PurchaseTicket : Form
    {
        public PurchaseTicket()
        {
            InitializeComponent();
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            
        }
        //Submit button code
        private void button1_Click(object sender, EventArgs e)
        {
            ////Validating the filling of input fields
            if (comboBox1.Text == "" || comboBox2.Text == "" || numericUpDown1.Value == 0 || (radioButton1.Checked==false && radioButton2.Checked == false))
            {
                MessageBox.Show("All the inputs are mandatory!", "Incomplete Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (comboBox1.Text==comboBox2.Text)
            {
                MessageBox.Show("Please enter different places in From and To!", "Indifferent Location", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                String trip = "";
                if (radioButton1.Checked == true)
                    trip = radioButton1.Text;
                else
                    trip = radioButton2.Text;

                MySqlConnection sqlconn = new MySqlConnection();
                MySqlCommand sqlcmd = new MySqlCommand();
                MySqlDataReader sqlRd;

                sqlconn.ConnectionString = "datasource=localhost; port=3306; username=root; database=nrails";
                sqlconn.Open();
                //Insert data into the database table
                sqlcmd.CommandText = "INSERT INTO `tickets`(`date`,`trip`,`source`,`dest`,`passengers`) VALUES('" + dateTimePicker1.Value.Date.ToString("yyyyMMdd") +
                    "','" + trip + "','" + comboBox1.Text + "','" + comboBox2.Text + "','" + numericUpDown1.Value + "')";
                sqlcmd.Connection = sqlconn;
                sqlRd = sqlcmd.ExecuteReader();
                sqlRd.Close();
                TimeSch tt = new TimeSch();
                tt.Show();
                this.Hide();
            }
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            SelectionWin sw = new SelectionWin();
            sw.Show();
        }
       
    }
}
